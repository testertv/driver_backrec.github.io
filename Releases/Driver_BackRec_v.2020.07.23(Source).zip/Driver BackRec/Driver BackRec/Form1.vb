﻿
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            TextBox1.Text = FolderBrowserDialog1.SelectedPath
            Dim root As Environment.SpecialFolder = FolderBrowserDialog1.RootFolder
        End If

    End Sub

    Private p As Process

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If Me.ComboBox1.SelectedIndex = -1 Or TextBox1.Text.Length = 0 Then
            MsgBox("Please select Drivers Folder or <<BackUp>>|<<Recovery>> option!")
            Exit Sub
        End If




        RichTextBox1.Text = "Please wait a moment..."
        RichTextBox1.Refresh()

        p = New Process()

        With p.StartInfo
            .CreateNoWindow = True
            .Verb = "runas"
            .FileName = "cmd"
            .RedirectStandardInput = True
            .RedirectStandardOutput = True
            .RedirectStandardError = True
            .UseShellExecute = False
            '.StandardOutputEncoding = System.Text.Encoding.Default
            .StandardOutputEncoding = System.Text.Encoding.GetEncoding("cp866") 'show russian text symbols
        End With

        p.Start()
        p.StandardInput.WriteLine("cd C:\WINDOWS\system32")

        If ComboBox1.SelectedItem = "BackUp" Then
            Dim CommandPlusDriversPathBackup As String = "dism /online /export-driver /destination:" & """" & Replace(TextBox1.Text, "/", "\") & """"
            p.StandardInput.WriteLine(CommandPlusDriversPathBackup)
        ElseIf ComboBox1.SelectedItem = "Recovery" Then
            Dim CommandPlusDriversPathRecovery As String = "pnputil /add-driver " & Replace(TextBox1.Text, "/", "\") & "\*.inf /subdirs /install"
            p.StandardInput.WriteLine(CommandPlusDriversPathRecovery)
        End If

        p.StandardInput.WriteLine("exit")
        RichTextBox1.Text = p.StandardOutput.ReadToEnd()

    End Sub
End Class
